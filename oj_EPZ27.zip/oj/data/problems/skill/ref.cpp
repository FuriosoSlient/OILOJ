#include <bits/stdc++.h>
using namespace std;
#define int long long
namespace DoubleQLzn
{
    struct Node
    {
        int m;
        vector<int> a, b;
        vector<array<int, 3>> p;
    };
    int n, x;
    vector<Node> v;
    void solve()
    {
        cin >> n >> x;
        v.assign(n, Node());
        for (int i = 0; i < n; i++)
        {
            int m;
            cin >> m;
            v[i].m = m;
            v[i].a.resize(m);
            v[i].b.resize(m);
            for (int j = 0; j < m; j++) cin >> v[i].a[j];
            for (int j = 0; j < m; j++) cin >> v[i].b[j];
            int cs = 0, mn = 0;
            for (int j = 0; j < m; j++)
            {
                cs -= v[i].a[j];
                mn = min(mn, cs);
                cs += v[i].b[j];
                if (cs > 0)
                {
                    v[i].p.push_back({-mn, cs, j + 1});
                    cs = 0;
                    mn = 0;
                }
            }
        }
        int cur = x;
        vector<int> ptr(n, 0);
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> q;
        for (int i = 0; i < n; i++)
        {
            if (ptr[i] < (int)v[i].p.size())
            {
                q.push({v[i].p[0][0], i});
            }
        }
        while (!q.empty() && q.top().first <= cur)
        {
            int req = q.top().first;
            int i = q.top().second;
            q.pop();
            cur += v[i].p[ptr[i]][1];
            ptr[i]++;
            if (ptr[i] < (int)v[i].p.size())
            {
                q.push({v[i].p[ptr[i]][0], i});
            }
        }
        int ma = cur;
        int ans = 0, bid = 1;
        for (int i = 0; i < n; i++)
        {
            cur = ma;
            int h = 0;
            if (ptr[i] > 0) h = v[i].p[ptr[i] - 1][2];
            for (int j = h; j < v[i].m; j++)
            {
                if (cur >= v[i].a[j])
                {
                    cur -= v[i].a[j];
                    cur += v[i].b[j];
                    h++;
                }
                else break;
            }
            if (h > ans)
            {
                ans = h;
                bid = i + 1;
            }
        }
        cout << ans << ' ' << bid << '\n';
    }
}
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int T;
    cin >> T;
    while (T--)
    {
        DoubleQLzn::solve();
    }
    return 0;
}