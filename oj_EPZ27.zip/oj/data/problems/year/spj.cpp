#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

const int N = 200005;
int n, k;
int a[N];

// Check if element at position pos is in some LIS
bool inLIS(int pos) {
    vector<int> dp1(n), dp2(n);
    vector<int> lis;
    for (int i = 0; i < n; i++) {
        auto it = lower_bound(lis.begin(), lis.end(), a[i]);
        if (it == lis.end()) lis.push_back(a[i]);
        else *it = a[i];
        dp1[i] = lis.size();
    }
    
    lis.clear();
    for (int i = n - 1; i >= 0; i--) {
        auto it = lower_bound(lis.begin(), lis.end(), -a[i]);
        if (it == lis.end()) lis.push_back(-a[i]);
        else *it = -a[i];
        dp2[i] = lis.size();
    }
    
    int lis_len = 0;
    for (int i = 0; i < n; i++) lis_len = max(lis_len, dp1[i]);
    
    return dp1[pos] + dp2[pos] - 1 == lis_len;
}

// Check if element at position pos is in some LDS
bool inLDS(int pos) {
    vector<int> dp1(n), dp2(n);
    vector<int> lds;
    for (int i = 0; i < n; i++) {
        auto it = lower_bound(lds.begin(), lds.end(), -a[i]);
        if (it == lds.end()) lds.push_back(-a[i]);
        else *it = -a[i];
        dp1[i] = lds.size();
    }
    
    lds.clear();
    for (int i = n - 1; i >= 0; i--) {
        auto it = lower_bound(lds.begin(), lds.end(), a[i]);
        if (it == lds.end()) lds.push_back(a[i]);
        else *it = a[i];
        dp2[i] = lds.size();
    }
    
    int lds_len = 0;
    for (int i = 0; i < n; i++) lds_len = max(lds_len, dp1[i]);
    
    return dp1[pos] + dp2[pos] - 1 == lds_len;
}

// Check if a solution exists for given n and k
bool hasSolution(int n, int k) {
    // No solution for k=0 and n<8
    if (k == 0 && n < 8) return false;
    // No solution for k=1 and 2<=n<=4
    if (k == 1 && n >= 2 && n <= 4) return false;
    // Solution exists for all other cases
    return true;
}

int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);
    
    int T = inf.readInt();
    
    for (int tc = 0; tc < T; tc++) {
        n = inf.readInt();
        k = inf.readInt();
        
        // Check if solution exists
        bool solvable = hasSolution(n, k);
        
        // Read participant's output
        string token = ouf.readToken();
        
        if (token == "-1") {
            // Output says no solution
            if (solvable) {
                quitf(_wa, "Jury finds a solution but your code outputs -1");
            }
            // Correctly outputs -1 for unsolvable case
            continue;
        }
        
        // Output says there is a solution
        if (!solvable) {
            quitf(_wa, "No solution exists but your code outputs a permutation");
        }
        
        // Parse the permutation
        vector<int> p(n);
        p[0] = stoi(token);
        for (int i = 1; i < n; i++) {
            p[i] = ouf.readInt();
        }
        
        // Check if it's a permutation of 1..n
        vector<bool> vis(n + 1, false);
        for (int i = 0; i < n; i++) {
            if (p[i] < 1 || p[i] > n) {
                quitf(_wa, "Permutation contains value out of range");
            }
            if (vis[p[i]]) {
                quitf(_wa, "Permutation contains duplicate value");
            }
            vis[p[i]] = true;
        }
        
        // Copy to global array
        for (int i = 0; i < n; i++) a[i] = p[i];
        
        // Count good elements
        int good = 0;
        for (int i = 0; i < n; i++) {
            if (inLIS(i) && inLDS(i)) good++;
        }
        
        if (good != k) {
            quitf(_wa, "Number of good elements is incorrect");
        }
    }
    
    // Verify all output has been read
    ouf.readEof();
    
    quitf(_ok, "All test cases passed");
    return 0;
}