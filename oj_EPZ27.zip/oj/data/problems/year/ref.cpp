#include <bits/stdc++.h>
using namespace std;
int dc = 1;
namespace DoubleQLzn
{
	void init()
	{
		return ;
	}
	void solve()
	{
		int n,k;
		cin >> n >> k;
		if (k == 0)
		{
			if (n < 8) cout << "-1\n";
			else
			{
				vector<int> tmp = {3,4,8,7,2,1,5,6};
				for (int i = 1;i <= n - 8;i++) cout << i << ' ';
				for (int i = 0;i < 8;i++) cout << tmp[i] + n - 8 << ' ';
				cout << '\n';
			}
		}
		else if (k == 1)
		{
			vector<int> tmp = {2,5,3,1,4};
			if (n == 1) cout << "1\n";
			else if (n < 5) cout << "-1\n";
			else 
			{
				for (int i = 1;i <= n - 5;i++) cout << i << ' ';
				for (int i = 0;i < 5;i++) cout << tmp[i] + n - 5 << ' ';
				cout << '\n';
			}
		}
		else 
		{
			for (int i = 1;i <= n - k;i++) cout << i << ' ';
			for (int i = n - k;i < n;i++) cout << 2 * n - k - i << ' ';
			cout << '\n';
		}
	}
}
int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int T;
	if (dc == 0) T = 1;
	else cin >> T;
	while (T--)
	{
		DoubleQLzn::init();
DoubleQLzn::solve();
	}
	return 0;
}