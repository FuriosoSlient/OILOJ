#include "testlib.h"
#include <iostream>
#include <vector>
#include <string>

using namespace std;

// 在一棵完全二叉树中（根为 1，节点 i 的父节点为 i/2）计算两点的 LCA
int get_lca(int a, int b) {
    while (a != b) {
        if (a > b) a /= 2;
        else b /= 2;
    }
    return a;
}

int main(int argc, char* argv[]) {
    // 注册交互器
    registerInteraction(argc, argv);

    // 1. 从标准输入读入测试数据
    int h = inf.readInt();
    int n = (1 << h) - 1;
    vector<int> p(n + 1);
    vector<int> pos(n + 1);
    
    // 读入排列 p 并记录每个标签所在的节点位置 (1-based index)
    for (int i = 1; i <= n; i++) {
        p[i] = inf.readInt();
        pos[p[i]] = i;
    }

    // 将树的高度输出给选手的标准输入
    cout << h << endl;

    int queries = 0;
    int max_queries = n + 420;

    while (true) {
        string type = ouf.readToken();
        
        // 选手发起查询操作
        if (type == "?") {
            queries++;
            
            // 如果查询次数超过限制，按照题意输出 -1 并判定为 WA
            if (queries > max_queries) {
                cout << -1 << endl;
                quitf(_wa, "Too many queries (max %d)", max_queries);
            }
            
            int u = ouf.readInt();
            int v = ouf.readInt();
            int w = ouf.readInt();

            // 检查选手提供的标签是否合法并互不相同
            if (u < 1 || u > n || v < 1 || v > n || w < 1 || w > n || u == v || u == w || v == w) {
                cout << -1 << endl;
                quitf(_wa, "Invalid query labels: %d, %d, %d", u, v, w);
            }

            int p_u = pos[u];
            int p_v = pos[v];
            int p_w = pos[w];

            // 树上三个节点的带根 LCA 必然是它们两两之间 LCA 中的中位数
            // 我们在原本以 1 为根的树中寻找这三个两两 LCA
            int l1 = get_lca(p_u, p_v);
            int l2 = get_lca(p_v, p_w);
            int l3 = get_lca(p_w, p_u);

            int median_pos;
            if (l1 == l2) {
                median_pos = l3;
            } else if (l2 == l3) {
                median_pos = l1;
            } else {
                median_pos = l2;
            }

            // 输出查询结果的标签
            cout << p[median_pos] << endl;
        } 
        // 选手给出最终答案
        else if (type == "!") {
            int r = ouf.readInt();
            if (r < 1 || r > n) {
                quitf(_wa, "Invalid guessed root label: %d", r);
            }
            
            if (r == p[1]) {
                quitf(_ok, "Guessed the root %d correctly in %d queries", r, queries);
            } else {
                quitf(_wa, "Guessed root %d, but actual root is %d", r, p[1]);
            }
        } 
        // 非法操作符
        else {
            cout << -1 << endl;
            quitf(_pe, "Expected '?' or '!', got %s", type.c_str());
        }
    }

    return 0;
}